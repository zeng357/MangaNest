# MangaNest · Usage Guide

MangaNest · Multi-Site Manga Downloader — full user guide (chapter-list edition, v1.7.3).

## Contents

1. Quick start
2. Home page (download workflow)
3. Format Converter page (merge manga into a book)
4. Settings page
5. Adding any new website (Auto Site Analyzer)
6. Self-check, logs & network repair
7. Add your own crawler (two ways)
8. Translate page (English manga → Chinese)
9. FAQ
10. Disclaimer

---

## 1. Quick start

- **Source version**: install Python 3.10 + dependencies (see README section 4), double-click `start.bat`.
- **Standalone EXE**: download from GitHub Releases, extract (EXE + `sites_data` + `custom-sites` + `config.json` in the same folder), double-click the EXE. No Python needed.

Both versions open the same GUI with three pages in the left sidebar: **🏠 Home · 🔄 Format Converter · ⚙ Settings**.

> Keep the console window open while downloading — progress is shown there. Close it or the main window to quit.

---

## 2. Home page (download workflow)

### 2.1 Step-by-step

1. **Site selector**: choose a manga website.
2. **Comic name**: type the manga title.
3. **Search**: click Search; candidates appear below. Click one to auto-fill and open its detail page.
4. **Need login** (optional): check it, then `Open Login` (a browser opens) → sign in (QR/account) → `Login Done` (Cookie saved). Required for chapters that need login.
5. **Load chapter list**: reads all chapters (number + name) and builds a checkable list.
6. **Select chapters**: check the ones to download (all / partial / range).
7. **Start download / Stop download**: the main button starts the selected chapters and downloads them into `ComicName/ChapterName/N.jpg`. While a run is active the same button reads **停止下载**; click it once to stop.
8. **Retry tools**: "Retry failed images" and "Retry failed chapters" for failures.

### 2.2 Folder structure

```
ComicName/
├── 0/cover.jpg                 # cover (0-prefixed folder = cover directory)
├── 128 Final-Chap/
│   ├── 1.jpg
│   └── ...
├── 128 Final-Chap.zip          # per-chapter package (ZIP or CBZ) beside the chapter folder
├── download_state.json         # chapter completion marks, used for resume
└── 127 Side-Story/
    ├── 1.jpg
    └── ...
```

### 2.3 Notes

- **VIP/paid chapters**: guests only see preview pages. After login, free chapters download fully; VIP paid chapters need a matching membership. The program never bypasses paywalls.
- Some sites lazy-load chapter lists/images — the program auto-scrolls and paginates.

### 2.4 Stop and resume

- **One button, two states**: when idle it reads **开始下载**; after a run starts it reads **停止下载**; after you click stop it shows **正在停止…** until the workers finish the request already in flight.
- **When stop takes effect**: before the next search, chapter collection, image request, retry, chapter package or final packaging step. The image currently downloading is allowed to finish; no new image or chapter is started.
- **What is kept**: every image and chapter already downloaded, the chapter list, and `image_urls.json`. The run is not rolled back.
- **How to continue**: use **下载失败图片** (retry failed images) or start the same chapter again. The next run reuses the saved image list and skips files that already exist.
- **Chapter packages**: ZIP/CBZ and `download_state.json` are written only for chapters that actually finished; a stopped chapter is left without a package mark so it can be resumed.

---

## 3. Format Converter page (merge manga into a book)

Turn downloaded manga images (JPG/PNG/WebP/GIF/BMP) into e-books: **PDF · CBZ · EPUB · MOBI**.

### 3.1 Add source folders

- **Add folder**: add a manga folder (a comic root, a chapter folder, anything containing images).
- **Scan sub-folders (batch)**: pick a comic root; every sub-folder that contains images is added at once.

### 3.2 Convert

| Control | What it does |
|---|---|
| **⚡ One-click whole-book merge** | Merges **all folders in the list (1 or many) into ONE file**, auto cover. Just click it. |
| **Start convert** | Converts per the current settings (whole book / per chapter, cover on/off). |
| Target format | PDF (universal) / CBZ (comic readers) / EPUB (e-book) / MOBI (requires Calibre installed). |
| Output folder | Where result files are saved. |
| **Per-chapter files** | On = one file per chapter (cover only on the first); off = one merged file. |
| **Add cover to first book** | Default on: uses the original manga cover automatically. |
| **Choose cover image** | Pick any image manually as the cover (overrides auto detection). |
| Convert log | Live progress for every file. |

### 3.3 Cover rules (auto)

1. Detects a **0-prefixed folder** (e.g. `0/cover.jpg`) as the original cover — prefers `cover.*`, else the first image in that folder.
2. No 0-folder → no extra cover; the first image naturally becomes the cover page.
3. Only the **first book** gets a cover.

### 3.4 Examples

- **One folder** (a comic root): add it, click ⚡ → one PDF with cover + all chapters.
- **Many folders** (chapter folders / several comics): add them all, click ⚡ → ONE merged file (name = first folder + " etc.").
- After conversion the source list clears automatically, ready for the next batch.

---

## 4. Settings page

- **Scrolling (v1.6.10)**: the settings page scrolls vertically — use the **mouse wheel** while the pointer is over the settings area, or drag the bar on the right edge. Previously the lower cards (下载设置 / 浏览器设置 / 代理设置) could be cut off on small windows with no way to reach them.
- **Image naming**: padding (001, 002…), naming pattern.
- **Chapter folder naming**: display style of chapter folders.
- **Window / download / browser options**: fonts, timeouts, headless mode, etc.

### 4.1 Proxy settings (hide your real IP)

Open **⚙ Settings → 代理设置**:

| Field | Meaning |
|---|---|
| **启用代理** | Master switch. Applies to image downloads **and** the browser |
| **来源 → 代理列表文件 / 订阅链接** | `proxies.txt` (one proxy per line) or a subscription URL (plain text or base64) |
| **列表文件** | Path to the proxy list; **生成模板** writes a commented `proxies.txt` for you |
| **订阅链接** | Only used when source = subscription |
| **浏览器出口** | Fixed exit for the browser, e.g. `http://127.0.0.1:7890`. Empty → first proxy in the list. For a rotating (dynamic IP) service, put its local gateway here |
| **代理全部不可用时回退直连** | On: downloads still finish (one request on your real IP). Off: fail loudly instead — use this if the IP must never be exposed |

Accepted formats: `http://127.0.0.1:7890`, `http://user:pass@1.2.3.4:8080`, `1.2.3.4:8080`, `1.2.3.4:8080:user:pass`, `socks5://1.2.3.4:1080` (SOCKS5 browser-only).

How rotation works: each image request takes the next exit (up to `proxy_max_tries`, default 3). An exit that fails 3 times in a row is cooled down for 90 s. Settings are saved to `config.json` immediately and apply from the next download.

### 4.2 Human-like pacing (anti-ban, always on)

`config.py`:

| Constant | Default | Effect |
|---|---|---|
| `HUMAN_MODE` | `True` | Master switch |
| `HUMAN_DELAY_MIN/MAX` | 0.3 / 0.9 s | Random extra wait after every image |
| `HUMAN_CHAPTER_PAUSE_MIN/MAX` | 1.5 / 4.0 s | Random pause between chapters |
| `HUMAN_MAX_CONCURRENCY` | 3 | Images downloaded in parallel per chapter |
| `HUMAN_MAX_THREADS` | 2 | Download threads |
| `HUMAN_BROWSER_PAUSE_MIN/MAX` | 0.6 / 1.6 s | Pause after every browser page navigation |
| `HUMAN_UA_POOL` | 4 Edge UAs | Rotating User-Agent for image requests |

Per-site crawlers can still declare tighter limits in their `CONFIG` (`chapter_concurrency`, `download_threads`, `download_concurrency`, `download_delay`) — the effective values are the **stricter** of the two, so a site can be slowed further but never sped past the human caps. Set `HUMAN_MODE = False` to restore the old full-speed behaviour.

**Site-level chapter pause (v1.4.2)**: a crawler may also set `chapter_pause_min` / `chapter_pause_max` (seconds). The downloader applies them for that site only and resets them when the run ends, so one slow site never slows the others. Example — 漫画客 (`sites_data/yumanhua_crawler.py`), the dedicated slow profile:

**Human reading model (v1.4.3, 漫画客 only)**: `download_pause_every` / `download_pause_extra_min` / `download_pause_extra_max` add a longer break every N images (a person pausing between pages), and the chapter page is now scrolled **one viewport at a time** with random pauses, occasional small scroll-backs and breaks — no more `scrollTo(0, scrollHeight)` bursts, which were the site's main script fingerprint. Values currently used:

```python
# 翻页（浏览器里，真实滚动事件）
#   每屏 90~120% 视口高度，每屏停 0.35~0.8s
#   每 10~16 屏回翻一点（0.2~0.4 视口）并停 0.5~1.0s
#   每 12~18 屏多停 2.5~5s；到底后再停 2~4s
'chapter_concurrency': 1,       # 一次只处理 1 章
'download_threads': 1,          # 单章 1 个下载线程
'download_concurrency': 1,      # 同时只发 1 个图片请求
'download_delay': 3.0,          # 每张图再加 3.0s（叠加随机抖动 ≈3.3~3.9s/张）
'download_pause_every': 8,      # 每 8 张多歇一次
'download_pause_extra_min': 6.0,
'download_pause_extra_max': 14.0,
'chapter_pause_min': 15.0,      # 章间停 15~35s
'chapter_pause_max': 35.0,
```

**设置自动同步到新站点 (v1.6.9)**: after you add a site (按钮 **添加站点** → 文件/文件夹, or save one in **站点分析器**), the new site shows up in the site dropdown and in every settings-page list immediately. It also **inherits the settings that are already in effect**: with 模拟人工范围 = 仅指定网站 and a non-empty list, the new site is added to `human_sites`; with 多线程高速下载 on and a non-empty list, it is added to `fast_thread_sites`. Deleting a site removes it from both lists. If a list was empty it stays empty (nothing is enabled silently). Global options — 采集模式 (`collect_mode`), 下载逻辑, 线程数, 超时, 图片命名, 章节文件夹命名 — already apply to every site, old or new.

**采集模式 (v1.6.8)**: settings → 下载设置 → **采集模式** has two radio buttons. **先采集全部再下载（默认）** keeps the original flow: every chapter's image links are collected first, then all chapters download. **边采集边下载（爬一章下一章）** collects one chapter's links, downloads that chapter right away, then continues to the next chapter — useful for long comics where the first images should start downloading while later chapters are still being crawled. Stored in `config.json` as `collect_mode` (`batch` / `stream`) and also written to `config.COLLECT_MODE`; you can switch back and forth at any time, and the mode is re-read right before each download starts. Cover, retries, thread count, failed-image record and the optional ZIP behave exactly the same in both modes. Note: in stream mode the download progress bar restarts for every chapter (its maximum is the number of images collected so far), and the 采集 progress counts chapters one by one.

**Multi-thread high-speed download (v1.6.7)**: settings → 下载设置 → tick **多线程高速下载（仅指定网站，不受模拟人工限速）**, then press **选择网站…** and tick the sites it should apply to (multi-select, 全选/全不选 available). Only the ticked sites take the fast path: 8 images downloaded concurrently by 8 threads, no per-image human delay, no site reading break (`download_pause_every` ignored), no chapter pause, and the 模拟人工 limits (≤3 concurrency / ≤2 threads) do not apply. All other sites are untouched and keep whatever pacing they had. Values live in `config.py` as `FAST_THREAD_CONCURRENCY` / `FAST_THREAD_WORKERS` (change them in `config.json` to tune), the switch and list are saved as `fast_thread` / `fast_thread_sites`. The flag is recomputed when you switch sites and again right before a download starts; the label beside the button shows whether the current site is covered. Note: this deliberately looks less human, so only enable it on sites that do not rate-limit aggressive downloads.

**漫画客节奏 (v1.6.7)**: settings → 下载设置 → **漫画客节奏** replaces the batch limit that used to be hard-coded in `sites_data/yumanhua_crawler.py`. **跟随全局设置（默认）** adds no site overrides, so 漫画客 downloads exactly like every other site — the 模拟人工下载 and 多线程高速下载 switches decide the pace. **批次限速** restores the old profile: 10 images → every thread pauses 150–300 s → next 10, 300–600 s between chapters, 2 threads / 2 image concurrency, one chapter collected at a time. Saved as `yumanhua_batch_limit` in `config.json`; switching it reaches an already-created crawler immediately and is re-read at the start of each chapter collection.

**No-sleep switch (v1.6.6)**: the Home page button row has a **禁止休眠（下载时不自动睡眠）** checkbox (between 下载失败图片 and 退出). When ticked the program calls Windows `SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED)` for as long as it runs, so a multi-hour download is not interrupted by the PC going to sleep or blanking the screen. Untick it, or close the window / press 退出, and it resets to `ES_CONTINUOUS` so your normal power plan applies again. The state is stored in `config.json` as `prevent_sleep` and restored on the next launch.

**Download logic (v1.6.5)**: settings → 下载设置 → **下载逻辑**. **新版（整批暂停）** = when the "every N images" pause triggers, every download thread waits together (nothing is fetched during the pause; best against sites that count batches). **旧版（逐张停顿）** = the v1.4.x behaviour, only the triggering thread sleeps and the others keep downloading (faster, but looks more like a bot). Stored as `download_engine` (`global` / `legacy`) in `config.json`, applies to all sites, no restart needed.

**Human mode scope (v1.6.4)**: the 模拟人工下载 checkbox has a **选择网站…** button beside it. Choose **全部网站** to apply the human-like pacing everywhere (previous behaviour), or **仅指定的网站** and tick one or more sites; only those sites get random pauses + low concurrency, every other site runs at the program's default speed. Saved as `human_scope` / `human_sites` in `config.json`; switching sites re-evaluates automatically and the label shows whether the current site is covered.

**mgread.io retries (v1.6.3)**: the site sits on an overseas server and frequently drops connections; a page that resets or stays blank is reloaded automatically, up to 8 attempts (blank is detected after 8 s). Chapter pagination (page 2 and beyond) is fetched as static HTML over the browser session, so a 200-chapter list takes seconds instead of minutes, and a page past the end ends pagination instead of retrying. Search prefers an exact slug match: `solo leveling` → `/manga/solo-leveling/` rather than `solo-leveling-arise`.

**mgread.io verification (v1.6.2)**: every page is behind a Cloudflare “Just a moment” check. Run once in **有头（显示窗口）** mode and complete the “Verify you are human” box; the browser profile for this site is persistent, so the clearance cookie is reused on later runs and headless works afterwards. No CAPTCHA is solved automatically — if you see the checkbox, click it.

**yumanhua batch mode (v1.6.1)**: this site is counted by request volume, so `SPEED_MODE` defaults to `'batch10'`: download 10 images → **all threads pause 150–300 s** (a shared pause gate in `downloader.py`, so no thread keeps fetching while another sleeps) → next 10 images; between chapters another 300–600 s; 2 threads / 2 image concurrency for this site only. Roughly 12–25 min per 50-image chapter. Other sites are unaffected. Switch to `'default'` if you want the normal speed back.

**Human mode (v1.6.0)**: the Settings page has a “模拟人工下载” checkbox, **on by default and shared by all sites**. It takes effect immediately and is stored in `config.json` as `human_mode`. When on: 0.3–0.9 s random pause per image, ≤3 image concurrency, ≤2 download threads, 1.5–4.0 s between chapters, random User-Agent and short pauses after browser navigation. When off: downloads use the thread/concurrency/delay values from Settings as-is.

**Speed profiles (v1.5.6)**: `SPEED_MODE` at the top of `sites_data/yumanhua_crawler.py` defaults to `'default'` — the site no longer overrides anything: no chapter-concurrency cap, no `download_threads` / `download_concurrency` / `download_delay`, no extra pauses. Downloads run with the program's built-in defaults and the values set in the GUI, exactly like every other site. Chapter collection opens several pages at once (using the GUI's "tabs" value) and closes each chapter's tab as soon as that chapter reaches the bottom. `'multi'`, `'t8'`, `'std'` and `'slow'` remain selectable if you ever want a different pace.

With these values a 50-page chapter takes roughly **6–7 minutes** (page turning + downloads), so a 94-chapter comic needs several hours. That is intentional: 漫画客 escalated from per-IP throttling to segment bans after high-speed batch runs. If you still hit 403/429/timeouts, stop the batch, enable a proxy exit in ⚙ Settings, and wait before retrying.

---

## 5. Adding any new website (Auto Site Analyzer)

Open **Auto Site Analyzer** from the Home page, follow 4 steps:

1. **Open & analyze**: paste the new site homepage; the program analyzes the search box and search entry.
2. **Trial search**: type a keyword; candidates are listed (filter/fix rules if needed).
3. **Analyze chapters**: opens the comic detail page; scrolls/paginates to find all chapters (with names).
4. **Analyze images → save adapter**: opens a chapter page, analyzes image structure, generates rules and **saves `custom-sites/newsite_adapter.json`** — reusable forever.

Refresh the site list afterwards; the new site behaves like built-in ones.

See `Docs/How-to-Add-a-New-Site.md` for the adapter JSON fields.

---

## 6. Self-check, logs & network repair

### 6.1 Self-check (v1.1)

Every launch runs a self-check: Python version, required modules, network socket, core files, writable directories.

- Result log: **`startup_diag.log`** (next to the program).
- Unexpected errors: **`crash.log`**.
- If a blocking error is found, a dialog points to the log file.

### 6.2 Network repair (WinError 10038)

If the program cannot create sockets / reach the internet:

1. Right-click **`fix-network-stack.bat`** → **Run as administrator** (resets Winsock, TCP/IP, DNS).
2. **Restart your PC**.
3. Connect normally afterwards.

> Format conversion is fully local — it works without internet.

---

## 7. Add your own crawler (two ways)

- **No coding** → Auto Site Analyzer wizard / "New Adapter" (JSON). See `Docs/How-to-Add-a-New-Site.md`.
- **Python** → "Crawler Source Manager" → "New from template" → edit → save; sources in `sites_data/` auto-load. See `Docs/How-to-Add-a-Custom-Crawler.md`.

---

## 8. Translate page (English manga → Chinese)

**What it does**: takes a downloaded chapter folder (English artwork) and produces the same pages with Chinese text, plus a block-by-block source/target list.

**Requirements**

1. Open-source engine **BallonsTranslator** installed at `tools/Ballonstranslator_win_minium/` (engine + models, ~4 GB, not shipped in this repo).
2. Our translator modules copied to `<BallonsTranslator>/custom_modules/`: `trans_hybrid.py`, `trans_nllb.py` (`Extensions/BallonsTranslator-custom-modules/`).
3. `<BallonsTranslator>/config/config.json`: `textdetector=ctd`, `ocr=mit48px`, `inpainter=lama_large_512px`, `translator=Hybrid`, `source=English`, `target=简体中文`.
4. Offline model `nllb-200-distilled-600M` (~2.4 GB) under `<BallonsTranslator>/data/models/`, or point `NLLB_MODEL_DIR` at it.

Full install/repair notes: `Docs/Translation.md`.

**Steps**

| Step | What happens |
|---|---|
| 1. Pick source folder | A chapter folder containing `1.jpg … N.jpg` (or single image) |
| 2. Output folder (optional) | Empty = auto `"<chapter folder> 汉化版"` next to the source |
| 3. Text only (optional) | Only exports `中英对照.txt`, skips image compositing (faster, less disk) |
| 4. Start | Runs in background thread; log window shows page/slice progress; Done dialog when finished |

**Output**

```
<output>/
  1.png … N.png         Chinese pages (same base names as the source images)
  中英对照.txt           per block: source text / translated text
```

**CLI equivalent**

```bat
python bt_slice_translate.py --input "<chapter>" --output "<out>"
python bt_slice_translate.py --input "<chapter>" --text-only
python bt_slice_translate.py --input "<chapter>" --slice 2000 --overlap 60 --keep-temp
```

`--keep-temp` keeps `_bt_work/` (slices, per-slice BallonsTranslator output, JSON, logs) — use it when a page still shows English and you want to see which slice failed.

**How it avoids three classic failures**

| Failure | Cause | Handling |
|---|---|---|
| English still visible | Whole page downscaled before detection → thin lines missed; punctuation outside the text box never masked | Slice to ~2000px before detection; residual ink detected on the inpainted base and erased by pixel mask |
| Empty bubbles (bubble frame erased) | Inpainter wipes area, OCR returned nothing | OCR-empty blocks are restored from the original artwork; Chinese is composited only where text was replaced |
| Translation missing on some blocks | A slice produced no result (engine crashed on exit) | Every missing slice is detected and re-run automatically (up to 3 rounds); leftovers listed in the log |

**Timing reference** (GTX 1050 4 GB): ~1–2 min per 800×9000 page; a 21-page chapter ≈ 25–35 min. CPU only: roughly 10× slower.

---

## 9. FAQ

| Problem | Cause & fix |
|---|---|
| Black window flashes and closes | BAT line-ending/encoding issue; use the original BAT, or run `python gui.py` |
| No module named 'xxx' | Missing dependency; install per README section 4 |
| Chapter list numbers only | Old bug; fixed — new version shows "Chap N + name" |
| Chapter downloads only 1–2 images | Paid/login chapter; guests see preview only; check "Need login" and retry |
| Search shows unrelated results | Some sites don't filter search; adapters apply keyword filter + fallback |
| Missing chapters / no next page | Lazy-loaded sites; new version auto-scrolls + paginates |
| Images include UI pictures | Restricted to real images inside the chapter container |
| Converted PDF won't open | Old object-number bug fixed in v1.1 — re-convert |
| Conversion still produces separate files | Use "⚡ One-click whole-book merge" |
| "Self-check found problems" | Open `startup_diag.log`; network → `fix-network-stack.bat` |

---

## 10. Disclaimer

Full disclaimer: `Docs/DISCLAIMER.txt` (English & Chinese). In short:

- For personal learning/research only; no commercial use.
- Downloaded content belongs to the original authors/platforms; delete within 24 hours; support the official releases.
- Obey each site's terms of service; use at your own risk.
- No paywall bypass / membership cracking / piracy distribution.
- Provided "as is" without warranty.

By using this software you agree to the terms above.
